const roles = {
    warrior: {
        name: "Warrior",
        icon: "⚔️",
        description: "Petarung garis depan yang tangguh dengan pertahanan kuat.",
        baseStats: {
            maxHp: 120,
            maxMp: 30,
            atk: 15,
            def: 10
        }
    },
    mage: {
        name: "Mage",
        icon: "🔮",
        description: "Perapal mantra dengan kekuatan sihir elemen dahsyat.",
        baseStats: {
            maxHp: 80,
            maxMp: 80,
            atk: 8,
            def: 5
        }
    },
    archer: {
        name: "Archer",
        icon: "🏹",
        description: "Penembak jitu lincah yang menyerang dari jarak jauh.",
        baseStats: {
            maxHp: 90,
            maxMp: 40,
            atk: 12,
            def: 6
        }
    },
    thief: {
        name: "Thief",
        icon: "🗡️",
        description: "Pencuri gesit yang mengandalkan kecepatan dan serangan kritis.",
        baseStats: {
            maxHp: 85,
            maxMp: 50,
            atk: 11,
            def: 7
        }
    },
    cleric: {
        name: "Cleric",
        icon: "✝️",
        description: "Penyembuh suci yang mendukung party dengan doa dan pemulihan.",
        baseStats: {
            maxHp: 95,
            maxMp: 70,
            atk: 7,
            def: 8
        }
    },
    berserker: {
        name: "Berserker",
        icon: "🪓",
        description: "Petarung brutal yang mengorbankan pertahanan demi serangan dahsyat.",
        baseStats: {
            maxHp: 110,
            maxMp: 20,
            atk: 18,
            def: 4
        }
    },
    paladin: {
        name: "Paladin",
        icon: "🛡️",
        description: "Kesatria suci dengan pertahanan kokoh dan sedikit kekuatan penyembuhan.",
        baseStats: {
            maxHp: 130,
            maxMp: 45,
            atk: 10,
            def: 12
        }
    },
    necromancer: {
        name: "Necromancer",
        icon: "💀",
        description: "Pengendali arwah dan sihir kegelapan.",
        baseStats: {
            maxHp: 85,
            maxMp: 75,
            atk: 9,
            def: 6
        }
    },
    summoner: {
        name: "Summoner",
        icon: "🌀",
        description: "Memanggil makhluk dari dimensi lain untuk bertarung.",
        baseStats: {
            maxHp: 90,
            maxMp: 65,
            atk: 7,
            def: 7
        }
    },
    knight: {
        name: "Knight",
        icon: "🐴",
        description: "Ahli pedang dan perisai dengan keseimbangan serangan dan pertahanan.",
        baseStats: {
            maxHp: 125,
            maxMp: 35,
            atk: 13,
            def: 11
        }
    },
    monk: {
        name: "Monk",
        icon: "👊",
        description: "Petarung tangan kosong yang fokus pada kecepatan dan serangan beruntun.",
        baseStats: {
            maxHp: 100,
            maxMp: 50,
            atk: 14,
            def: 8
        }
    },
    druid: {
        name: "Druid",
        icon: "🌳",
        description: "Penjaga alam yang bisa berubah wujud dan menggunakan sihir alam.",
        baseStats: {
            maxHp: 95,
            maxMp: 60,
            atk: 9,
            def: 9
        }
    },
    assassin: {
        name: "Assassin",
        icon: "🔪",
        description: "Pembunuh bayaran yang ahli dalam serangan diam-diam dan racun.",
        baseStats: {
            maxHp: 80,
            maxMp: 45,
            atk: 13,
            def: 5
        }
    },
    bard: {
        name: "Bard",
        icon: "🎶",
        description: "Penyair pengembara yang menggunakan lagu untuk mendukung sekutu dan melemahkan musuh.",
        baseStats: {
            maxHp: 90,
            maxMp: 65,
            atk: 6,
            def: 6
        }
    },
    alchemist: {
        name: "Alchemist",
        icon: "🧪",
        description: "Ahli ramuan dan peledak, menciptakan berbagai efek di medan perang.",
        baseStats: {
            maxHp: 85,
            maxMp: 55,
            atk: 7,
            def: 7
        }
    },
    spellblade: {
        name: "Spellblade",
        icon: "✨",
        description: "Petarung yang menggabungkan ilmu pedang dengan sihir elemen.",
        baseStats: {
            maxHp: 100,
            maxMp: 50,
            atk: 12,
            def: 8
        }
    },
    ranger: {
        name: "Ranger",
        icon: "🌲",
        description: "Penjelajah hutan yang ahli bertahan hidup dan bertarung bersama hewan peliharaan.",
        baseStats: {
            maxHp: 95,
            maxMp: 40,
            atk: 11,
            def: 7
        }
    }
};

const items = {
    'potion': {
        name: 'Potion',
        type: 'consumable',
        description: 'Memulihkan 100 HP.',
        effect: {
            hp: 100
        },
        value: 20,
        buyPrice: 40,
        healAmount: 100,
        emoji: '🧪'
    },
    'hi-potion': {
        name: 'Hi-Potion',
        type: 'consumable',
        description: 'Memulihkan 300 HP.',
        effect: {
            hp: 300
        },
        value: 80,
        buyPrice: 160,
        healAmount: 300,
        emoji: '🧪'
    },
    'x-potion': {
        name: 'X-Potion',
        type: 'consumable',
        description: 'Memulihkan 800 HP.',
        effect: {
            hp: 800
        },
        value: 250,
        buyPrice: 500,
        healAmount: 800,
        emoji: '🧪'
    },
    'mega-potion': {
        name: 'Mega-Potion',
        type: 'consumable',
        description: 'Memulihkan 2000 HP.',
        effect: {
            hp: 2000
        },
        value: 600,
        buyPrice: 1200,
        healAmount: 2000,
        emoji: '🧪'
    },
    'mana-potion': {
        name: 'Mana Potion',
        type: 'consumable',
        description: 'Memulihkan 60 MP.',
        effect: {
            mp: 60
        },
        value: 30,
        buyPrice: 60,
        emoji: '💧'
    },
    'hi-mana-potion': {
        name: 'Hi-Mana Potion',
        type: 'consumable',
        description: 'Memulihkan 200 MP.',
        effect: {
            mp: 200
        },
        value: 100,
        buyPrice: 200,
        emoji: '💧'
    },
    'ether': {
        name: 'Ether',
        type: 'consumable',
        description: 'Memulihkan 500 MP.',
        effect: {
            mp: 500
        },
        value: 300,
        buyPrice: 600,
        emoji: '💧'
    },
    'elixir': {
        name: 'Elixir',
        type: 'consumable',
        description: 'Memulihkan HP & MP sepenuhnya.',
        effect: {
            hp: 9999,
            mp: 9999
        },
        value: 800,
        buyPrice: 1600,
        emoji: '🌟'
    },
    'phoenix-down': {
        name: 'Phoenix Down',
        type: 'consumable',
        description: 'Menghidupkan kembali rekan party yang gugur (fitur party).',
        effect: {
            revive: 1
        },
        value: 1500,
        buyPrice: 3000,
        emoji: '🕊️'
    },
    'antidote': {
        name: 'Antidote',
        type: 'consumable',
        description: 'Menyembuhkan status Poison.',
        effect: {
            cure: 'poison'
        },
        value: 15,
        buyPrice: 30,
        emoji: '🌿'
    },
    'panacea': {
        name: 'Panacea',
        type: 'consumable',
        description: 'Menyembuhkan semua status negatif umum.',
        effect: {
            cure_all_common: true
        },
        value: 100,
        buyPrice: 200,
        emoji: '💊'
    },
    'potion-of-strength': {
        name: 'Potion of Strength',
        type: 'consumable',
        description: 'Meningkatkan ATK sebesar 10% selama 5 menit.',
        effect: {
            buff_atk_percent: 0.10,
            buff_duration: 300000
        },
        value: 75,
        buyPrice: 150,
        emoji: '💪'
    },
    'potion-of-fortitude': {
        name: 'Potion of Fortitude',
        type: 'consumable',
        description: 'Meningkatkan DEF sebesar 10% selama 5 menit.',
        effect: {
            buff_def_percent: 0.10,
            buff_duration: 300000
        },
        value: 75,
        buyPrice: 150,
        emoji: '🛡️'
    },
    'potion-of-clarity': {
        name: 'Potion of Clarity',
        type: 'consumable',
        description: 'Mempercepat regenerasi MP selama 5 menit.',
        effect: {
            buff_mp_regen: 5,
            buff_duration: 300000
        },
        value: 75,
        buyPrice: 150,
        emoji: '🧠'
    },
    'roti-tawar': {
        name: 'Roti Tawar',
        type: 'consumable',
        description: 'Roti biasa, sedikit memulihkan HP.',
        effect: {
            hp: 40
        },
        value: 5,
        buyPrice: 10,
        healAmount: 40,
        emoji: '🍞'
    },
    'apel': {
        name: 'Apel',
        type: 'consumable',
        description: 'Buah apel segar.',
        effect: {
            hp: 30
        },
        value: 3,
        buyPrice: 8,
        healAmount: 30,
        emoji: '🍎'
    },
    'daging-panggang': {
        name: 'Daging Panggang',
        type: 'consumable',
        description: 'Daging lezat, memulihkan HP lumayan.',
        effect: {
            hp: 150
        },
        value: 30,
        buyPrice: 70,
        healAmount: 150,
        emoji: '🍖'
    },

    'pedang-kayu': {
        name: 'Pedang Kayu',
        type: 'weapon',
        slot: 'weapon',
        description: 'Pedang latihan dasar.',
        stats: {
            atk: 5
        },
        value: 10,
        buyPrice: 25,
        roles: ['warrior', 'paladin', 'berserker', 'knight', 'thief', 'spellblade', 'ranger'],
        emoji: '🗡️'
    },
    'pedang-besi': {
        name: 'Pedang Besi',
        type: 'weapon',
        slot: 'weapon',
        description: 'Pedang besi standar.',
        stats: {
            atk: 12
        },
        value: 80,
        buyPrice: 180,
        roles: ['warrior', 'paladin', 'berserker', 'knight', 'spellblade'],
        emoji: '🗡️'
    },
    'silver-greatsword': {
        name: 'Silver Greatsword',
        type: 'weapon',
        slot: 'weapon',
        description: 'Pedang besar perak, efektif melawan undead.',
        stats: {
            atk: 20
        },
        value: 350,
        buyPrice: 750,
        roles: ['warrior', 'paladin', 'knight'],
        emoji: '⚔️'
    },
    'dragonbone-blade': {
        name: 'Dragonbone Blade',
        type: 'weapon',
        slot: 'weapon',
        description: 'Pedang legendaris ditempa dari tulang naga.',
        stats: {
            atk: 35
        },
        value: 1500,
        buyPrice: 3200,
        roles: ['warrior', 'knight', 'paladin'],
        emoji: '🐉'
    },
    'tongkat-kayu': {
        name: 'Tongkat Kayu',
        type: 'weapon',
        slot: 'weapon',
        description: 'Tongkat sihir pemula.',
        stats: {
            atk: 3,
            mp: 15
        },
        value: 10,
        buyPrice: 25,
        roles: ['mage', 'cleric', 'necromancer', 'summoner', 'druid', 'alchemist', 'bard'],
        emoji: '🪄'
    },
    'apprentice-staff': {
        name: 'Apprentice Staff',
        type: 'weapon',
        slot: 'weapon',
        description: 'Tongkat standar untuk penyihir muda.',
        stats: {
            atk: 6,
            mp: 30
        },
        value: 90,
        buyPrice: 200,
        roles: ['mage', 'cleric', 'necromancer', 'summoner', 'druid'],
        emoji: '🪄'
    },
    'mages-crystal-staff': {
        name: 'Mage\'s Crystal Staff',
        type: 'weapon',
        slot: 'weapon',
        description: 'Tongkat dengan kristal sihir untuk amplifikasi.',
        stats: {
            atk: 10,
            mp: 50
        },
        value: 400,
        buyPrice: 850,
        roles: ['mage', 'summoner', 'spellblade'],
        emoji: '💎'
    },
    'archlich-staff': {
        name: 'Archlich Staff',
        type: 'weapon',
        slot: 'weapon',
        description: 'Tongkat gelap yang menyerap jiwa.',
        stats: {
            atk: 18,
            mp: 70
        },
        value: 1800,
        buyPrice: 3800,
        roles: ['necromancer', 'mage'],
        emoji: '💀'
    },
    'busur-pendek': {
        name: 'Busur Pendek',
        type: 'weapon',
        slot: 'weapon',
        description: 'Busur panah sederhana.',
        stats: {
            atk: 8
        },
        value: 60,
        buyPrice: 140,
        roles: ['archer', 'ranger', 'bard'],
        emoji: '🏹'
    },
    'longbow': {
        name: 'Longbow',
        type: 'weapon',
        slot: 'weapon',
        description: 'Busur panjang untuk jangkauan lebih jauh.',
        stats: {
            atk: 14
        },
        value: 180,
        buyPrice: 400,
        roles: ['archer', 'ranger'],
        emoji: '🏹'
    },
    'elven-composite-bow': {
        name: 'Elven Composite Bow',
        type: 'weapon',
        slot: 'weapon',
        description: 'Busur elegan buatan Elf, sangat akurat.',
        stats: {
            atk: 22
        },
        value: 500,
        buyPrice: 1100,
        roles: ['archer', 'ranger'],
        emoji: '🌿'
    },
    'phoenix-bow': {
        name: 'Phoenix Bow',
        type: 'weapon',
        slot: 'weapon',
        description: 'Busur yang diberkati api Phoenix, panahnya membara.',
        stats: {
            atk: 30
        },
        value: 1600,
        buyPrice: 3500,
        roles: ['archer', 'ranger'],
        emoji: '🔥'
    },
    'baju-kain': {
        name: 'Baju Kain',
        type: 'armor',
        slot: 'body',
        description: 'Pakaian kain biasa.',
        stats: {
            def: 2
        },
        value: 10,
        buyPrice: 20,
        emoji: '👕'
    },
    'ragged-tunic': {
        name: 'Ragged Tunic',
        type: 'armor',
        slot: 'body',
        description: 'Jubah compang-camping, lebih baik dari tidak sama sekali.',
        stats: {
            def: 3
        },
        value: 15,
        buyPrice: 35,
        emoji: '🧥'
    },
    'leather-jerkin': {
        name: 'Leather Jerkin',
        type: 'armor',
        slot: 'body',
        description: 'Jaket kulit untuk perlindungan dasar.',
        stats: {
            def: 6
        },
        value: 70,
        buyPrice: 150,
        emoji: '🧥'
    },
    'chainmail-vest': {
        name: 'Chainmail Vest',
        type: 'armor',
        slot: 'body',
        description: 'Rompi rantai besi untuk perlindungan sedang.',
        stats: {
            def: 10
        },
        value: 200,
        buyPrice: 420,
        roles: ['warrior', 'paladin', 'knight'],
        emoji: '⛓️'
    },
    'steel-plate-armor': {
        name: 'Steel Plate Armor',
        type: 'armor',
        slot: 'body',
        description: 'Zirah pelat baja yang kokoh.',
        stats: {
            def: 18
        },
        value: 600,
        buyPrice: 1300,
        roles: ['warrior', 'paladin', 'knight'],
        emoji: '🛡️'
    },
    'mage-robes-of-warding': {
        name: 'Mage Robes of Warding',
        type: 'armor',
        slot: 'body',
        description: 'Jubah sihir yang ditenun dengan mantra pelindung.',
        stats: {
            def: 8,
            mp: 20
        },
        value: 550,
        buyPrice: 1200,
        roles: ['mage', 'cleric', 'necromancer', 'summoner'],
        emoji: '🔮'
    },
    'dragonscale-mail': {
        name: 'Dragonscale Mail',
        type: 'armor',
        slot: 'body',
        description: 'Zirah langka terbuat dari sisik naga yang sangat kuat.',
        stats: {
            def: 30
        },
        value: 2000,
        buyPrice: 4500,
        roles: ['warrior', 'knight', 'paladin'],
        emoji: '🐉'
    },
    'archmages-mantle': {
        name: 'Archmage\'s Mantle',
        type: 'armor',
        slot: 'body',
        description: 'Mantel legendaris yang memperkuat semua sihir.',
        stats: {
            def: 12,
            mp: 50
        },
        value: 1800,
        buyPrice: 4000,
        roles: ['mage', 'necromancer', 'summoner'],
        emoji: '🌟'
    },
    'wooden-buckler': {
        name: 'Wooden Buckler',
        type: 'armor',
        slot: 'shield',
        description: 'Perisai kayu kecil untuk menangkis.',
        stats: {
            def: 3
        },
        value: 30,
        buyPrice: 70,
        emoji: '🛡️'
    },
    'iron-round-shield': {
        name: 'Iron Round Shield',
        type: 'armor',
        slot: 'shield',
        description: 'Perisai besi bundar standar.',
        stats: {
            def: 7
        },
        value: 120,
        buyPrice: 250,
        roles: ['warrior', 'paladin', 'knight', 'cleric'],
        emoji: '🛡️'
    },
    'steel-kite-shield': {
        name: 'Steel Kite Shield',
        type: 'armor',
        slot: 'shield',
        description: 'Perisai baja besar berbentuk layang-layang.',
        stats: {
            def: 12
        },
        value: 450,
        buyPrice: 950,
        roles: ['warrior', 'paladin', 'knight'],
        emoji: '🛡️'
    },
    'dragons-aegis': {
        name: 'Dragon\'s Aegis',
        type: 'armor',
        slot: 'shield',
        description: 'Perisai legendaris yang tahan api naga.',
        stats: {
            def: 25
        },
        value: 1700,
        buyPrice: 3600,
        roles: ['warrior', 'paladin', 'knight'],
        emoji: '🐉'
    },
    'kulit-goblin': {
        name: 'Kulit Goblin',
        type: 'material',
        description: 'Kulit keras dari goblin.',
        value: 5,
        buyPrice: 0,
        emoji: '🟢'
    },
    'sayap-kelelawar': {
        name: 'Sayap Kelelawar',
        type: 'material',
        description: 'Sayap kelelawar biasa.',
        value: 4,
        buyPrice: 0,
        emoji: '🦇'
    },
    'taring-serigala': {
        name: 'Taring Serigala',
        type: 'material',
        description: 'Taring tajam dari serigala hutan.',
        value: 8,
        buyPrice: 0,
        emoji: '🐺'
    },
    'batu-sihir-kecil': {
        name: 'Batu Sihir Kecil',
        type: 'material',
        description: 'Batu dengan sedikit energi sihir.',
        value: 25,
        buyPrice: 0,
        emoji: '✨'
    },
    'permata-kasar': {
        name: 'Permata Kasar',
        type: 'material',
        description: 'Batu permata yang belum diasah.',
        value: 80,
        buyPrice: 0,
        emoji: '💎'
    },
    'emas-murni': {
        name: 'Emas Murni',
        type: 'material',
        description: 'Batangan emas murni.',
        value: 150,
        buyPrice: 0,
        emoji: '💰'
    },
    'inti-golem': {
        name: 'Inti Golem',
        type: 'material',
        description: 'Inti energi dari golem batu.',
        value: 120,
        buyPrice: 0,
        emoji: '🗿'
    },
    'bulu-griffin': {
        name: 'Bulu Griffin',
        type: 'material',
        description: 'Sehelai bulu indah dari Griffin.',
        value: 180,
        buyPrice: 0,
        emoji: '깃털'
    },
    'sisik-naga': {
        name: 'Sisik Naga',
        type: 'material',
        description: 'Sisik keras dari seekor naga (langka).',
        value: 800,
        buyPrice: 0,
        emoji: '🐉'
    },
    'akar-mandragora': {
        name: 'Akar Mandragora',
        type: 'material',
        description: 'Akar ajaib yang berteriak.',
        value: 100,
        buyPrice: 0,
        emoji: '🌱'
    },
    'bubuk-peri': {
        name: 'Bubuk Peri',
        type: 'material',
        description: 'Debu berkilauan dari sayap peri.',
        value: 130,
        buyPrice: 0,
        emoji: '🧚'
    },
    'tulang-undead': {
        name: 'Tulang Undead',
        type: 'material',
        description: 'Potongan tulang dari kerangka.',
        value: 7,
        buyPrice: 0,
        emoji: '🦴'
    },
    'lendir-slime': {
        name: 'Lendir Slime',
        type: 'material',
        description: 'Lendir lengket dari slime.',
        value: 2,
        buyPrice: 0,
        emoji: '🦠'
    },
    'besi-karat': {
        name: 'Besi Karat',
        type: 'material',
        description: 'Potongan besi tua.',
        value: 4,
        buyPrice: 0,
        emoji: '🔩'
    },
    'kain-robek': {
        name: 'Kain Robek',
        type: 'material',
        description: 'Potongan kain bekas.',
        value: 2,
        buyPrice: 0,
        emoji: '🏳️'
    },
    'jamur-aneh': {
        name: 'Jamur Aneh',
        type: 'material',
        description: 'Jamur dengan warna mencurigakan.',
        value: 12,
        buyPrice: 0,
        emoji: '🍄'
    },
    'bunga-malam': {
        name: 'Bunga Malam',
        type: 'material',
        description: 'Bunga yang mekar hanya di malam hari.',
        value: 35,
        buyPrice: 0,
        emoji: '🌸'
    },
    'racun-kalajengking': {
        name: 'Racun Kalajengking',
        type: 'material',
        description: 'Racun mematikan dari ekor kalajengking.',
        value: 150,
        buyPrice: 0,
        emoji: '🦂'
    },
    'bijih-besi': {
        name: 'Bijih Besi',
        type: 'material',
        description: 'Bongkahan bijih besi mentah.',
        value: 18,
        buyPrice: 0,
        emoji: '🪨'
    },
    'bijih-perak': {
        name: 'Bijih Perak',
        type: 'material',
        description: 'Bongkahan bijih perak berkilau.',
        value: 50,
        buyPrice: 0,
        emoji: '🥈'
    },
    'bijih-emas': {
        name: 'Bijih Emas',
        type: 'material',
        description: 'Bongkahan bijih emas.',
        value: 130,
        buyPrice: 0,
        emoji: '🥇'
    },
    'bijih-mithril': {
        name: 'Bijih Mithril',
        type: 'material',
        description: 'Logam langka yang sangat kuat dan ringan.',
        value: 300,
        buyPrice: 0,
        emoji: '🔩'
    },
    'bijih-adamantite': {
        name: 'Bijih Adamantite',
        type: 'material',
        description: 'Logam terkeras yang diketahui, hampir mustahil ditempa.',
        value: 700,
        buyPrice: 0,
        emoji: '🌑'
    },
    'kayu-log': {
        name: 'Kayu Log',
        type: 'material',
        description: 'Potongan kayu gelondongan.',
        value: 8,
        buyPrice: 0,
        emoji: '🪵'
    },
    'enchanted-wood': {
        name: 'Kayu Bertuah',
        type: 'material',
        description: 'Kayu yang dialiri energi sihir alam.',
        value: 150,
        buyPrice: 0,
        emoji: '🌳'
    },
    'kulit-binatang': {
        name: 'Kulit Binatang',
        type: 'material',
        description: 'Kulit hewan liar.',
        value: 10,
        buyPrice: 0,
        emoji: '🐾'
    },
    'benang-sutra': {
        name: 'Benang Sutra',
        type: 'material',
        description: 'Benang halus dari ulat sutra.',
        value: 40,
        buyPrice: 0,
        emoji: '🧵'
    },
    'batu-obsidian': {
        name: 'Batu Obsidian',
        type: 'material',
        description: 'Batu vulkanik hitam tajam.',
        value: 70,
        buyPrice: 0,
        emoji: '🌑'
    },
    'mystic-essence': {
        name: 'Esensi Mistis',
        type: 'material',
        description: 'Konsentrasi energi sihir murni.',
        value: 250,
        buyPrice: 0,
        emoji: '✨'
    },
    'goblin-ear': {
        name: 'Telinga Goblin',
        type: 'material',
        description: 'Telinga runcing dari Goblin, sering dijadikan trofi.',
        value: 6,
        buyPrice: 0,
        emoji: '👂'
    },
    'spider-silk': {
        name: 'Sutra Laba-laba',
        type: 'material',
        description: 'Benang kuat dari laba-laba raksasa.',
        value: 20,
        buyPrice: 0,
        emoji: '🕸️'
    },
    'orc-tusk': {
        name: 'Taring Orc',
        type: 'material',
        description: 'Taring besar dan kasar dari Orc.',
        value: 45,
        buyPrice: 0,
        emoji: '🦷'
    },
    'drake-scale': {
        name: 'Sisik Drake',
        type: 'material',
        description: 'Sisik keras dari Drake muda.',
        value: 200,
        buyPrice: 0,
        emoji: '🐲'
    },
    'demon-horn': {
        name: 'Tanduk Iblis',
        type: 'material',
        description: 'Tanduk melengkung dari Iblis kecil.',
        value: 400,
        buyPrice: 0,
        emoji: '😈'
    },
    'angel-feather': {
        name: 'Bulu Malaikat',
        type: 'material',
        description: 'Sehelai bulu suci yang jatuh dari surga.',
        value: 1000,
        buyPrice: 0,
        emoji: '😇'
    },
    'kunci-karat': {
        name: 'Kunci Karat',
        type: 'key_item',
        description: 'Kunci tua yang mungkin membuka sesuatu.',
        value: 0,
        emoji: '🗝️'
    },
    'peta-harta': {
        name: 'Peta Harta',
        type: 'key_item',
        description: 'Peta menuju harta karun tersembunyi.',
        value: 0,
        emoji: '🗺️'
    },
    'lisensi-petualang': {
        name: 'Lisensi Petualang',
        type: 'key_item',
        description: 'Bukti resmi sebagai petualang.',
        value: 0,
        emoji: '📜'
    },
    'orb-elemen-api': {
        name: 'Orb Elemen Api',
        type: 'key_item',
        description: 'Bola berisi kekuatan api murni.',
        value: 0,
        emoji: '🔥'
    },
    'orb-elemen-air': {
        name: 'Orb Elemen Air',
        type: 'key_item',
        description: 'Bola berisi kekuatan air murni.',
        value: 0,
        emoji: '💧'
    },
    'orb-elemen-tanah': {
        name: 'Orb Elemen Tanah',
        type: 'key_item',
        description: 'Bola berisi kekuatan tanah murni.',
        value: 0,
        emoji: '🌍'
    },
    'orb-elemen-angin': {
        name: 'Orb Elemen Angin',
        type: 'key_item',
        description: 'Bola berisi kekuatan angin murni.',
        value: 0,
        emoji: '💨'
    },
    'pecahan-tablet-kuno': {
        name: 'Pecahan Tablet Kuno',
        type: 'key_item',
        description: 'Bagian dari artefak kuno.',
        value: 0,
        emoji: '🧱'
    },
    'jimat-keberuntungan': {
        name: 'Jimat Keberuntungan',
        type: 'key_item',
        description: 'Jimat yang katanya membawa hoki.',
        value: 0,
        emoji: '🍀'
    },
    'kunci-guild': {
        name: 'Kunci Guild',
        type: 'key_item',
        description: 'Kunci markas guild.',
        value: 0,
        emoji: '🔑'
    },
    'surat-cinta': {
        name: 'Surat Cinta',
        type: 'key_item',
        description: 'Surat pernyataan cinta (untuk quest?).',
        value: 0,
        emoji: '💌'
    },
    'crypt-key': {
        name: 'Kunci Kripta',
        type: 'key_item',
        description: 'Kunci untuk membuka bagian terdalam Kripta Terkutuk.',
        value: 0,
        emoji: '🗝️'
    },
    'dragons-tear': {
        name: 'Air Mata Naga',
        type: 'key_item',
        description: 'Kristal langka yang terbentuk dari air mata naga.',
        value: 0,
        emoji: '💧'
    },
    'ancient-scroll': {
        name: 'Gulungan Kuno',
        type: 'key_item',
        description: 'Gulungan berisi pengetahuan atau sihir kuno.',
        value: 0,
        emoji: '📜'
    },
    'gold': {
        name: 'Emas',
        type: 'currency',
        description: 'Mata uang utama.',
        value: 1,
        emoji: '🪙'
    },
    'silver': {
        name: 'Perak',
        type: 'currency',
        description: 'Mata uang sekunder.',
        value: 0.1,
        emoji: '🔘'
    },
    'emerald': {
        name: 'Emerald',
        type: 'material',
        description: 'Batu permata hijau berharga.',
        value: 250,
        buyPrice: 0,
        emoji: '✳️'
    },
    'ruby': {
        name: 'Ruby',
        type: 'material',
        description: 'Batu permata merah berharga.',
        value: 300,
        buyPrice: 0,
        emoji: '♦️'
    },
    'sapphire': {
        name: 'Sapphire',
        type: 'material',
        description: 'Batu permata biru berharga.',
        value: 280,
        buyPrice: 0,
        emoji: '💠'
    },
    'diamond': {
        name: 'Diamond',
        type: 'material',
        description: 'Batu permata paling berharga.',
        value: 1200,
        buyPrice: 0,
        emoji: '💎'
    },
};

const dungeons = [{
        id: "dg001",
        name: "Hutan Goblin Pemula",
        description: "Hutan lebat yang menjadi sarang goblin-goblin pemula dan lemah.",
        levelRequirement: 1,
        duration: 15000, // 15 detik
        monsters: ["Goblin Kecil", "Goblin Pemanah", "Hobgoblin"],
        rewards: {
            goldMin: 150, // Naik
            goldMax: 350, // Naik
            xpMin: 200, // Naik
            xpMax: 450, // Naik
            items: ['kulit-goblin', 'potion', 'pedang-kayu', 'baju-kain', 'besi-karat', 'apel', 'goblin-ear'],
            itemChance: 0.85, // Naik
            maxItems: 3
        },
        cooldown: 120000,
        events: ["Menemukan jejak kaki kecil.", "Mendengar suara tawa goblin.", "Melewati perangkap sederhana."]
    },
    {
        id: "dg002",
        name: "Gua Kelelawar Gelap",
        description: "Gua gelap tempat bersemayamnya kelelawar raksasa dan makhluk malam lainnya.",
        levelRequirement: 3,
        duration: 15000, // 15 detik
        monsters: ["Kelelawar Raksasa", "Kelelawar Vampir Kecil", "Induk Kelelawar", "Spider-Cave"],
        rewards: {
            goldMin: 250, // Naik
            goldMax: 500, // Naik
            xpMin: 300, // Naik
            xpMax: 650, // Naik
            items: ['sayap-kelelawar', 'potion', 'batu-sihir-kecil', 'antidote', 'jamur-aneh', 'spider-silk'],
            itemChance: 0.80, // Naik
            maxItems: 3
        },
        cooldown: 180000,
        events: ["Merasa ada yang terbang di atas kepala.", "Menemukan guano.", "Mendengar suara decitan keras."]
    },
    {
        id: "dg003",
        name: "Reruntuhan Kuno Terlupakan",
        description: "Reruntuhan kuno yang dijaga oleh golem batu pelindung dan roh penasaran.",
        levelRequirement: 5,
        duration: 20000, // 20 detik
        monsters: ["Golem Batu Kecil", "Golem Tanah", "Golem Penjaga", "Ancient Spirit"],
        rewards: {
            goldMin: 400, // Naik
            goldMax: 800, // Naik
            xpMin: 500, // Naik
            xpMax: 1000, // Naik
            items: ['batu-sihir-kecil', 'hi-potion', 'pedang-besi', 'baju-kulit', 'permata-kasar', 'inti-golem', 'kunci-karat', 'ancient-scroll'],
            itemChance: 0.85, // Naik
            maxItems: 4
        },
        cooldown: 240000,
        events: ["Menemukan ukiran kuno di dinding.", "Merasa tanah bergetar.", "Melewati lorong sempit."]
    },
    {
        id: "dg004",
        name: "Hutan Serigala Misterius",
        description: "Hutan berkabut yang menjadi wilayah kekuasaan kawanan serigala licik dan kuat.",
        levelRequirement: 7,
        duration: 18000, // 18 detik
        monsters: ["Serigala Lapar", "Serigala Alfa", "Dire Wolf", "Shadow Wolf"],
        rewards: {
            goldMin: 600, // Naik
            goldMax: 1100, // Naik
            xpMin: 700, // Naik
            xpMax: 1200, // Naik
            items: ['taring-serigala', 'hi-potion', 'leather-jerkin', 'busur-pendek', 'kulit-binatang', 'daging-panggang'],
            itemChance: 0.82, // Naik
            maxItems: 3
        },
        cooldown: 300000,
        events: ["Mendengar lolongan serigala.", "Menemukan sisa mangsa.", "Bersembunyi di balik pohon besar."]
    },
    {
        id: "dg005",
        name: "Kripta Tulang Belulang",
        description: "Kuil pemakaman tua yang kini dihuni oleh arwah resah dan pasukan undead.",
        levelRequirement: 10,
        duration: 25000, // 25 detik
        monsters: ["Skeleton Warrior", "Ghost", "Zombie Lord", "Wraith Elite"],
        rewards: {
            goldMin: 900, // Naik
            goldMax: 1600, // Naik
            xpMin: 1000, // Naik
            xpMax: 1800, // Naik
            items: ['batu-sihir-kecil', 'silver-greatsword', 'hi-mana-potion', 'chainmail-vest', 'holy-water', 'tulang-undead', 'emas-murni', 'pecahan-tablet-kuno', 'crypt-key'],
            itemChance: 0.88, // Naik
            maxItems: 4
        },
        cooldown: 360000,
        events: ["Merasakan hawa dingin menusuk.", "Melihat bayangan bergerak.", "Mendengar suara bisikan."]
    },
    {
        id: "dg006",
        name: "Rawa Mandragora Berduri",
        description: "Rawa gelap tempat Mandragora dan monster rawa lainnya mengintai.",
        levelRequirement: 12,
        duration: 20000, // 20 detik
        monsters: ["Mandragora Queen", "Swamp Slime", "Giant Leech", "Bog Serpent"],
        rewards: {
            goldMin: 1100,
            goldMax: 2000,
            xpMin: 1300,
            xpMax: 2200,
            items: ['akar-mandragora', 'lendir-slime', 'hi-potion', 'mana-potion', 'antidote', 'jamur-aneh', 'mystic-essence'],
            itemChance: 0.80,
            maxItems: 3
        },
        cooldown: 420000,
        events: ["Terjebak lumpur hisap.", "Mendengar tangisan aneh.", "Menemukan jejak makhluk rawa."]
    },
    {
        id: "dg007",
        name: "Puncak Badai Griffin",
        description: "Puncak gunung terjal yang selalu diselimuti badai, rumah bagi Griffin perkasa.",
        levelRequirement: 15,
        duration: 30000, // 30 detik
        monsters: ["Storm Harpy", "Griffin Alpha", "Roc Hatchling", "Tempest Elemental"],
        rewards: {
            goldMin: 1400,
            goldMax: 2500,
            xpMin: 1600,
            xpMax: 2800,
            items: ['bulu-griffin', 'hi-potion', 'hi-mana-potion', 'longbow', 'chainmail-vest', 'permata-kasar', 'bunga-malam', 'sapphire'],
            itemChance: 0.75,
            maxItems: 4
        },
        cooldown: 480000,
        events: ["Merasakan hembusan angin kencang.", "Melihat bayangan besar di langit.", "Menemukan sarang telur raksasa."]
    },
    {
        id: "dg008",
        name: "Benteng Darah Orc",
        description: "Benteng pertahanan bangsa Orc yang dipenuhi prajurit haus darah.",
        levelRequirement: 18,
        duration: 28000, // 28 detik
        monsters: ["Orc Marauder", "Orc Sharpshooter", "Orc Berserker Elite", "Orc War Chief"],
        rewards: {
            goldMin: 1700,
            goldMax: 3200,
            xpMin: 2000,
            xpMax: 3600,
            items: ['orc-tusk', 'steel-plate-armor', 'potion-of-strength', 'x-potion', 'emas-murni', 'iron-round-shield', 'bijih-mithril'],
            itemChance: 0.85,
            maxItems: 4
        },
        cooldown: 540000,
        events: ["Mendengar suara genderang perang.", "Melihat asap dari perkemahan Ork.", "Menghindari patroli Ork."]
    },
    {
        id: "dg009",
        name: "Labirin Minotaur Abadi",
        description: "Labirin terkutuk yang dijaga oleh Minotaur abadi dan jebakan mematikan.",
        levelRequirement: 20,
        duration: 30000, // 30 detik
        monsters: ["Minotaur Immortal", "Grave Golem", "Phantom Imp", "Stone Gargoyle Lord"],
        rewards: {
            goldMin: 2000,
            goldMax: 3800,
            xpMin: 2400,
            xpMax: 4200,
            items: ['inti-golem', 'peta-harta', 'x-potion', 'elixir', 'potion-of-fortitude', 'steel-kite-shield', 'jimat-keberuntungan', 'ruby'],
            itemChance: 0.80,
            maxItems: 3
        },
        cooldown: 600000,
        events: ["Tersesat di persimpangan.", "Menemukan tulang belulang.", "Mendengar suara langkah berat."]
    },
    {
        id: "dg010",
        name: "Kawah Naga Mengamuk", // Nama sudah bagus
        description: "Gunung berapi aktif tempat tinggal Naga Merah perkasa dan pengikutnya.",
        levelRequirement: 25,
        duration: 30000, // Diperpendek
        monsters: ["Lava Slime", "Fire Elemental", "Salamander Overlord", "Young Red Dragon", "Drake"],
        rewards: {
            goldMin: 2500, // Naik
            goldMax: 5000, // Naik
            xpMin: 3000, // Naik
            xpMax: 5500, // Naik
            items: ['sisik-naga', 'elixir', 'phoenix-down', 'emas-murni', 'orb-elemen-api', 'mages-crystal-staff', 'ruby', 'drake-scale', 'dragons-tear', 'diamond'],
            itemChance: 0.92, // Naik
            maxItems: 5
        },
        cooldown: 720000, // Diperpendek sedikit
        events: ["Merasakan panas menyengat.", "Melihat aliran lahar.", "Menemukan jejak cakar raksasa."]
    },
    {
        id: "dg011",
        name: "Belantara Peri Tersembunyi",
        description: "Hutan ajaib yang dilindungi oleh para Peri bijaksana dan makhluk mistis penjaga.",
        levelRequirement: 22,
        duration: 28000,
        monsters: ["Pixie Trickster", "Forest Sprite Guardian", "Ancient Dryad", "Lesser Treant Protector"],
        rewards: {
            goldMin: 1800,
            goldMax: 3500,
            xpMin: 2200,
            xpMax: 3800,
            items: ['bubuk-peri', 'bunga-malam', 'hi-mana-potion', 'mage-robes-of-warding', 'apprentice-staff', 'emerald', 'enchanted-wood'],
            itemChance: 0.80,
            maxItems: 4
        },
        cooldown: 660000,
        events: ["Mendengar nyanyian peri.", "Melihat cahaya ajaib di antara pepohonan.", "Berinteraksi dengan hewan hutan."]
    },
    {
        id: "dg012",
        name: "Nekropolis Para Raja",
        description: "Kompleks pemakaman agung yang menjadi domain para undead bangsawan.",
        levelRequirement: 28,
        duration: 30000,
        monsters: ["Lich Adept", "Revenant Knight", "Royal Mummy", "Screaming Banshee Queen"],
        rewards: {
            goldMin: 2800,
            goldMax: 5200,
            xpMin: 3200,
            xpMax: 5800,
            items: ['tulang-undead', 'emas-murni', 'elixir', 'silver-greatsword', 'holy-water', 'pecahan-tablet-kuno', 'batu-obsidian', 'mystic-essence'],
            itemChance: 0.88,
            maxItems: 5
        },
        cooldown: 800000,
        events: ["Menemukan sarkofagus terbuka.", "Melihat tulisan hieroglif.", "Mendengar rintihan arwah."]
    },
    {
        id: "dg013",
        name: "Gurun Kalajengking Kaisar",
        description: "Gurun tandus yang dikuasai oleh Kalajengking Kaisar raksasa dan pasukannya.",
        levelRequirement: 30,
        duration: 25000,
        monsters: ["Venomous Sand Scorpion", "Giant Emperor Scorpion", "Dune Worm Larva", "Desert Djinn"],
        rewards: {
            goldMin: 2200,
            goldMax: 4200,
            xpMin: 2600,
            xpMax: 4500,
            items: ['racun-kalajengking', 'panacea', 'potion-of-strength', 'elven-composite-bow', 'ragged-tunic', 'sapphire', 'spider-silk'],
            itemChance: 0.78,
            maxItems: 3
        },
        cooldown: 750000,
        events: ["Melihat fatamorgana.", "Menemukan oasis kecil.", "Terkena badai pasir."]
    },
    {
        id: "dg014",
        name: "Istana Hantu Berdarah",
        description: "Istana megah yang kini dikuasai oleh arwah bangsawan haus darah dan vampir.",
        levelRequirement: 32,
        duration: 30000,
        monsters: ["Vampire Thrall", "Specter Duchess", "Blood Poltergeist", "Vampire Lordling"],
        rewards: {
            goldMin: 3200,
            goldMax: 6000,
            xpMin: 3800,
            xpMax: 6500,
            items: ['emas-murni', 'elixir', 'phoenix-down', 'jimat-keberuntungan', 'permata-kasar', 'ruby', 'demon-horn'],
            itemChance: 0.83,
            maxItems: 4
        },
        cooldown: 900000,
        events: ["Mendengar suara piano misterius.", "Melihat lukisan bergerak.", "Pintu tertutup sendiri."]
    },
    {
        id: "dg015",
        name: "Domain Kraken Abyss",
        description: "Pulau terpencil dan laut dalam yang dikuasai oleh Kraken purba dan pelayan lautnya.",
        levelRequirement: 35,
        duration: 28000,
        monsters: ["Abyssal Siren", "Titanic Crab", "Deep Water Elemental", "Kraken's Chosen Tentacle"],
        rewards: {
            goldMin: 3500,
            goldMax: 6500,
            xpMin: 4200,
            xpMax: 7200,
            items: ['permata-kasar', 'orb-elemen-air', 'x-potion', 'hi-mana-potion', 'peta-harta', 'sapphire', 'diamond'],
            itemChance: 0.80,
            maxItems: 4
        },
        cooldown: 1000000,
        events: ["Melihat kapal karam.", "Menemukan mutiara raksasa.", "Terkena badai laut."]
    },
    {
        id: "dg016",
        name: "Tambang Mithril Terkutuk",
        description: "Tambang dalam yang ditinggalkan, kini dijaga oleh roh penambang dan monster logam.",
        levelRequirement: 38, // Naik
        duration: 25000,
        monsters: ["Kobold Geomancer", "Mithril Golem", "Rust Monster", "Undead Miner Captain"],
        rewards: {
            goldMin: 3800,
            goldMax: 7000,
            xpMin: 4500,
            xpMax: 7800,
            items: ['bijih-mithril', 'permata-kasar', 'x-potion', 'steel-plate-armor', 'steel-kite-shield', 'bijih-besi', 'bijih-perak', 'emerald'],
            itemChance: 0.82,
            maxItems: 4
        },
        cooldown: 1200000,
        events: ["Menemukan rel kereta tambang rusak.", "Melihat permata berkilau di dinding.", "Lorong runtuh sebagian."]
    },
    {
        id: "dg017",
        name: "Padang Perburuan Centaur Suci",
        description: "Padang rumput luas tempat suku Centaur terhormat menguji para pejuang.",
        levelRequirement: 40, // Naik
        duration: 20000,
        monsters: ["Centaur Champion", "Centaur Mystic", "War Boar Alpha", "Pegasus Colt"],
        rewards: {
            goldMin: 4000,
            goldMax: 7500,
            xpMin: 4800,
            xpMax: 8200,
            items: ['elven-composite-bow', 'hi-potion', 'potion-of-strength', 'dragonscale-mail', 'kulit-binatang', 'enchanted-wood'],
            itemChance: 0.75,
            maxItems: 3
        },
        cooldown: 1500000,
        events: ["Melihat perkemahan Centaur dari jauh.", "Menemukan jejak kuda.", "Mengikuti sungai kecil."]
    },
    {
        id: "dg018",
        name: "Menara Kosmik Sang Ahli Nujum",
        description: "Menara tinggi tempat seorang ahli nujum mempelajari bintang dan entitas kosmik.",
        levelRequirement: 42, // Naik
        duration: 30000,
        monsters: ["Cosmic Imp", "Celestial Guardian", "Failed Starspawn", "Mad Astrologer"],
        rewards: {
            goldMin: 4500,
            goldMax: 8500,
            xpMin: 5200,
            xpMax: 9000,
            items: ['archlich-staff', 'archmages-mantle', 'elixir', 'batu-sihir-kecil', 'orb-elemen-angin', 'diamond', 'mystic-essence'],
            itemChance: 0.88,
            maxItems: 4
        },
        cooldown: 1800000,
        events: ["Melihat buku-buku sihir berserakan.", "Menemukan laboratorium alkimia.", "Mendengar suara ledakan dari atas."]
    },
    {
        id: "dg019",
        name: "Kota Bawah Tanah Terlarang",
        description: "Kota kuno di kedalaman bumi yang dihuni oleh Dark Elf penyihir dan monster bayangan.",
        levelRequirement: 45, // Naik
        duration: 28000,
        monsters: ["Dark Elf Sorceress", "Phase Spider Queen", "Shadow Mastiff", "Beholder Tyrant"],
        rewards: {
            goldMin: 5000,
            goldMax: 9500,
            xpMin: 6000,
            xpMax: 10500,
            items: ['permata-kasar', 'emas-murni', 'archlich-staff', 'phoenix-bow', 'phoenix-down', 'peta-harta', 'batu-obsidian', 'benang-sutra', 'bijih-adamantite'],
            itemChance: 0.85,
            maxItems: 5
        },
        cooldown: 2400000,
        events: ["Menemukan jaring laba-laba raksasa.", "Melihat kristal berpendar.", "Melewati jembatan batu yang rapuh."]
    },
    {
        id: "dg020",
        name: "Gerbang Neraka Terbuka",
        description: "Retakan dimensi yang menjadi portal utama ke dunia bawah, dijaga iblis kuat.",
        levelRequirement: 50,
        rankRequirement: "S", // Tambah
        duration: 30000, // Sama
        monsters: ["Greater Demon", "Cerberus Pup", "Arch Succubus", "Balor General"],
        rewards: {
            goldMin: 7000, // Naik signifikan
            goldMax: 12000, // Naik signifikan
            xpMin: 8000, // Naik signifikan
            xpMax: 15000, // Naik signifikan
            items: ['orb-elemen-api', 'elixir', 'demon-horn', 'emas-murni', 'phoenix-down', 'ruby', 'diamond', 'angel-feather'], // Angel feather kontras
            itemChance: 0.95, // Naik
            maxItems: 5
        },
        cooldown: 3600000, // Naik sedikit
        events: ["Mencium bau belerang.", "Melihat api neraka.", "Mendengar jeritan dari kejauhan."]
    },
    {
        id: "dg021",
        name: "Jantung Glasier Abadi",
        description: "Inti dari gunung es raksasa, tempat tinggal Frost Wyrm kuno.",
        levelRequirement: 52,
        rankRequirement: "S",
        duration: 28000,
        monsters: ["Ice Golem Lord", "Alpha Frost Wolf", "Ancient Yeti Chieftain", "Young Frost Wyrm"],
        rewards: {
            goldMin: 7500,
            goldMax: 13000,
            xpMin: 8500,
            xpMax: 16000,
            items: ['orb-elemen-air', 'mega-potion', 'sapphire', 'dragonscale-mail', 'diamond', 'dragons-tear'],
            itemChance: 0.88,
            maxItems: 4
        },
        cooldown: 4000000,
        events: ["Merasakan angin dingin yang membekukan.", "Berjalan di atas danau es.", "Menemukan gua es tersembunyi."]
    },
    {
        id: "dg022",
        name: "Singgasana Kuil Langit",
        description: "Bagian tertinggi kuil melayang, dijaga oleh entitas surgawi terkuat.",
        levelRequirement: 55,
        rankRequirement: "SS",
        duration: 30000,
        monsters: ["Griffin Emperor", "Storm Elemental Avatar", "Elder Roc Matriarch", "Celestial Dragon"],
        rewards: {
            goldMin: 8000,
            goldMax: 15000,
            xpMin: 9000,
            xpMax: 17000,
            items: ['orb-elemen-angin', 'elixir', 'angel-feather', 'phoenix-bow', 'diamond', 'mystic-essence'],
            itemChance: 0.90,
            maxItems: 4
        },
        cooldown: 4500000,
        events: ["Berjalan di atas awan.", "Melihat pelangi ganda.", "Mendengar musik surgawi."]
    },
    {
        id: "dg023",
        name: "Lembah Prasejarah Terlarang",
        description: "Lembah tersembunyi tempat dinosaurus paling ganas dan kuno berkuasa.",
        levelRequirement: 58,
        rankRequirement: "SS",
        duration: 25000,
        monsters: ["Alpha Raptor Packleader", "Titanic Treant", "Quetzalcoatlus Rex", "Apex Tyrannosaurus"],
        rewards: {
            goldMin: 9000,
            goldMax: 17000,
            xpMin: 10000,
            xpMax: 19000,
            items: ['akar-mandragora', 'mega-potion', 'emerald', 'dragonbone-blade', 'taring-serigala', 'diamond', 'bijih-adamantite'],
            itemChance: 0.85,
            maxItems: 5
        },
        cooldown: 5000000,
        events: ["Menemukan fosil raksasa.", "Melihat jejak kaki dinosaurus.", "Bersembunyi dari predator puncak."]
    },
    {
        id: "dg024",
        name: "Dimensi Cermin Kekacauan",
        description: "Dimensi labirin yang diciptakan oleh entitas ilusi kuno, penuh jebakan pikiran.",
        levelRequirement: 60,
        rankRequirement: "SSS",
        duration: 28000,
        monsters: ["Master Doppelganger", "Void Shadow Lord", "Shattered Mirror Demon", "Illusory God-Fragment"],
        rewards: {
            goldMin: 10000,
            goldMax: 20000,
            xpMin: 12000,
            xpMax: 22000,
            items: ['batu-obsidian', 'elixir', 'phoenix-down', 'archmages-mantle', 'archlich-staff', 'diamond', 'mystic-essence'],
            itemChance: 0.92,
            maxItems: 5
        },
        cooldown: 6000000,
        events: ["Melihat bayangan diri sendiri menyerang.", "Dinding berubah menjadi cermin.", "Tersesat dalam labirin refleksi."]
    },
    {
        id: "dg025",
        name: "Kastil Raja Iblis Abyssal",
        description: "Benteng tergelap di kedalaman Abyss, tempat Raja Iblis bersemayam. HANYA PARTY!",
        levelRequirement: 70, 
        rankRequirement: "SSS",
        duration: 45000, 
        isPartyOnly: true, 
        monsters: ["Abyssal Archdemon", "Hellfire Cerberus", "Queen of Succubi", "Demon King's Right Hand", "THE DEMON KING"],
        rewards: {
            goldMin: 50000,
            goldMax: 100000,
            xpMin: 80000,
            xpMax: 150000,
            items: ['orb-elemen-api', 'orb-elemen-air', 'orb-elemen-tanah', 'orb-elemen-angin', 'angel-feather', 'demon-horn', 'dragons-aegis', 'phoenix-bow', 'diamond', 'ancient-scroll', 'dragons-tear'],
            itemChance: 1.0, 
            maxItems: 7 
        },
        cooldown: 86400000, 
        events: ["Aura kegelapan mencekik.", "Gerbang kastil terbuka perlahan.", "Teriakan para iblis terdengar.", "Raja Iblis menunggumu."]
    }
];

const quests = {
    "q001": {
        id: "q001",
        name: "Pembasmi Goblin Cilik",
        description: "Basmi 8 Goblin Kecil di Hutan Goblin Pemula.",
        levelRequirement: 1,
        objectives: [{
            type: "kill",
            target: "Goblin Kecil",
            count: 8,
            location: "dg001"
        }],
        rewards: {
            gold: 150,
            xp: 200,
            items: {
                'potion': 3,
                'goblin-ear': 2
            }
        },
        isRepeatable: true
    },
    "q002": {
        id: "q002",
        name: "Kulit untuk Zirah Baru",
        description: "Kumpulkan 5 Kulit Goblin dari Hutan Goblin Pemula.",
        levelRequirement: 1,
        objectives: [{
            type: "collect",
            target: "kulit-goblin",
            count: 5,
            location: "dg001"
        }],
        rewards: {
            gold: 120,
            xp: 150,
            items: {
                'baju-kain': 1
            }
        },
        isRepeatable: true
    },
    "q003": {
        id: "q003",
        name: "Misteri Gua Kelelawar",
        description: "Selidiki Gua Kelelawar Gelap dan kalahkan Induk Kelelawar yang mengganggu.",
        levelRequirement: 3,
        objectives: [{
            type: "kill",
            target: "Induk Kelelawar",
            count: 1,
            location: "dg002"
        }],
        rewards: {
            gold: 300,
            xp: 400,
            items: {
                'antidote': 5,
                'spider-silk': 3
            }
        },
        isRepeatable: false
    },
    "q004": {
        id: "q004",
        name: "Bahan Ramuan Penyihir",
        description: "Kumpulkan 8 Sayap Kelelawar dari Gua Kelelawar Gelap.",
        levelRequirement: 3,
        objectives: [{
            type: "collect",
            target: "sayap-kelelawar",
            count: 8,
            location: "dg002"
        }],
        rewards: {
            gold: 180,
            xp: 250,
            items: {
                'mana-potion': 2
            }
        },
        isRepeatable: true
    },
    "q005": {
        id: "q005",
        name: "Penjaga Batu Reruntuhan",
        description: "Kalahkan 3 Golem Penjaga di Reruntuhan Kuno Terlupakan.",
        levelRequirement: 5,
        objectives: [{
            type: "kill",
            target: "Golem Penjaga",
            count: 3,
            location: "dg003"
        }],
        rewards: {
            gold: 450,
            xp: 500,
            items: {
                'permata-kasar': 2,
                'ancient-scroll': 1
            }
        },
        isRepeatable: true
    },
    "q006": {
        id: "q006",
        name: "Relik dari Kedalaman",
        description: "Temukan 1 Kunci Karat di Reruntuhan Kuno Terlupakan.",
        levelRequirement: 5,
        objectives: [{
            type: "collect",
            target: "kunci-karat",
            count: 1,
            location: "dg003"
        }],
        rewards: {
            gold: 300,
            xp: 350,
            items: {
                'pedang-besi': 1
            }
        },
        isRepeatable: false
    },
    "q007": {
        id: "q007",
        name: "Teror Serigala Hutan Kabut",
        description: "Kalahkan Shadow Wolf yang meneror pedagang di Hutan Serigala Misterius.",
        levelRequirement: 7,
        objectives: [{
            type: "kill",
            target: "Shadow Wolf",
            count: 2,
            location: "dg004"
        }],
        rewards: {
            gold: 700,
            xp: 800,
            items: {
                'leather-jerkin': 1,
                'taring-serigala': 5
            }
        },
        isRepeatable: true
    },
    "q008": {
        id: "q008",
        name: "Perburuan Taring Alfa",
        description: "Kumpulkan 3 Taring Serigala Alfa dari Hutan Serigala Misterius.",
        levelRequirement: 8,
        objectives: [{
            type: "collect",
            target: "taring-serigala", // Asumsi taring alfa juga drop taring biasa
            count: 10, // Butuh lebih banyak untuk mensimulasikan kelangkaan
            location: "dg004"
        }],
        rewards: {
            gold: 500,
            xp: 600,
            items: {
                'potion-of-strength': 1
            }
        },
        isRepeatable: true
    },
    "q009": {
        id: "q009",
        name: "Membersihkan Kripta Terkutuk",
        description: "Basmi 15 Undead (Skeleton/Zombie Lord/Wraith) di Kripta Tulang Belulang.",
        levelRequirement: 10,
        objectives: [{
            type: "kill",
            target: ["Skeleton Warrior", "Zombie Lord", "Wraith Elite"],
            count: 15,
            location: "dg005"
        }],
        rewards: {
            gold: 1000,
            xp: 1200,
            items: {
                'silver-greatsword': 1,
                'holy-water': 3
            }
        },
        isRepeatable: true
    },
    "q010": {
        id: "q010",
        name: "Relik Kripta Suci",
        description: "Temukan Pecahan Tablet Kuno dan Kunci Kripta di Kripta Tulang Belulang.",
        levelRequirement: 11,
        objectives: [{
            type: "collect",
            target: "pecahan-tablet-kuno",
            count: 1,
            location: "dg005"
        }, {
            type: "collect",
            target: "crypt-key",
            count: 1,
            location: "dg005"
        }],
        rewards: {
            gold: 800,
            xp: 1000,
            items: {
                'elixir': 1
            }
        },
        isRepeatable: false
    },
    "q011": {
        id: "q011",
        name: "Ancaman Ratu Mandragora",
        description: "Kalahkan Mandragora Queen yang menguasai Rawa Mandragora Berduri.",
        levelRequirement: 12,
        objectives: [{
            type: "kill",
            target: "Mandragora Queen",
            count: 1,
            location: "dg006"
        }],
        rewards: {
            gold: 1200,
            xp: 1500,
            items: {
                'antidote': 3,
                'mystic-essence': 1
            }
        },
        isRepeatable: true
    },
    "q012": {
        id: "q012",
        name: "Herbalis Butuh Akar Langka",
        description: "Kumpulkan 6 Akar Mandragora dari Rawa Mandragora Berduri.",
        levelRequirement: 13,
        objectives: [{
            type: "collect",
            target: "akar-mandragora",
            count: 6,
            location: "dg006"
        }],
        rewards: {
            gold: 900,
            xp: 1100,
            items: {
                'hi-potion': 5
            }
        },
        isRepeatable: true
    },
    "q013": {
        id: "q013",
        name: "Bulu Griffin Mulia",
        description: "Kumpulkan 3 Bulu Griffin Alpha dari Puncak Badai Griffin.",
        levelRequirement: 15,
        objectives: [{
            type: "collect",
            target: "bulu-griffin", // Asumsi drop sama
            count: 8, // Butuh lebih banyak
            location: "dg007"
        }],
        rewards: {
            gold: 1500,
            xp: 1800,
            items: {
                'hi-potion': 5,
                'sapphire': 1
            }
        },
        isRepeatable: true
    },
    "q014": {
        id: "q014",
        name: "Penakluk Badai Puncak",
        description: "Kalahkan 2 Tempest Elemental di Puncak Badai Griffin.",
        levelRequirement: 16,
        objectives: [{
            type: "kill",
            target: "Tempest Elemental",
            count: 2,
            location: "dg007"
        }],
        rewards: {
            gold: 1300,
            xp: 1600,
            items: {
                'orb-elemen-angin': 1
            }
        },
        isRepeatable: true
    },
    "q015": {
        id: "q015",
        name: "Serbuan ke Benteng Orc",
        description: "Kalahkan Orc War Chief yang memimpin di Benteng Darah Orc.",
        levelRequirement: 18,
        objectives: [{
            type: "kill",
            target: "Orc War Chief",
            count: 1,
            location: "dg008"
        }],
        rewards: {
            gold: 2000,
            xp: 2500,
            items: {
                'steel-plate-armor': 1,
                'bijih-mithril': 2
            }
        },
        isRepeatable: false
    },
    "q016": {
        id: "q016",
        name: "Trofi Taring Orc",
        description: "Kumpulkan 10 Taring Orc dari para prajurit di Benteng Darah Orc.",
        levelRequirement: 19,
        objectives: [{
            type: "collect",
            target: "orc-tusk",
            count: 10,
            location: "dg008"
        }],
        rewards: {
            gold: 1600,
            xp: 2000,
            items: {
                'potion-of-strength': 2
            }
        },
        isRepeatable: true
    },
    "q017": {
        id: "q017",
        name: "Menaklukkan Labirin Abadi",
        description: "Temukan Peta Harta yang tersembunyi di Labirin Minotaur Abadi.",
        levelRequirement: 20,
        objectives: [{
            type: "collect",
            target: "peta-harta",
            count: 1,
            location: "dg009"
        }],
        rewards: {
            gold: 1800,
            xp: 2200,
            items: {
                'x-potion': 3,
                'ruby': 1
            }
        },
        isRepeatable: false
    },
    "q018": {
        id: "q018",
        name: "Penjaga Abadi Labirin",
        description: "Kalahkan Minotaur Immortal yang menjaga Labirin Minotaur Abadi.",
        levelRequirement: 21,
        objectives: [{
            type: "kill",
            target: "Minotaur Immortal",
            count: 1,
            location: "dg009"
        }],
        rewards: {
            gold: 2500,
            xp: 3000,
            items: {
                'steel-kite-shield': 1,
                'jimat-keberuntungan': 1
            }
        },
        isRepeatable: false
    },
    "q019": {
        id: "q019",
        name: "Pengumpul Esensi Peri",
        description: "Kumpulkan 5 Bubuk Peri dan 2 Kayu Bertuah dari Belantara Peri Tersembunyi.",
        levelRequirement: 22,
        objectives: [{
            type: "collect",
            target: "bubuk-peri",
            count: 5,
            location: "dg011"
        }, {
            type: "collect",
            target: "enchanted-wood",
            count: 2,
            location: "dg011"
        }],
        rewards: {
            gold: 2000,
            xp: 2400,
            items: {
                'emerald': 1
            }
        },
        isRepeatable: true
    },
    "q020": {
        id: "q020",
        name: "Pelindung Hutan Kuno",
        description: "Kalahkan 2 Ancient Dryad di Belantara Peri Tersembunyi.",
        levelRequirement: 23,
        objectives: [{
            type: "kill",
            target: "Ancient Dryad",
            count: 2,
            location: "dg011"
        }],
        rewards: {
            gold: 1900,
            xp: 2300,
            items: {
                'hi-mana-potion': 3,
                'mage-robes-of-warding': 1
            }
        },
        isRepeatable: true
    },
    "q021": {
        id: "q021",
        name: "Pemburu Naga Muda",
        description: "Kalahkan Young Red Dragon yang ganas di Kawah Naga Mengamuk.",
        levelRequirement: 25,
        objectives: [{
            type: "kill",
            target: "Young Red Dragon",
            count: 1,
            location: "dg010"
        }],
        rewards: {
            gold: 3500,
            xp: 4200,
            items: {
                'sisik-naga': 2,
                'elixir': 2,
                'dragons-tear': 1,
                'drake-scale': 3
            }
        },
        isRepeatable: false
    },
    "q022": {
        id: "q022",
        name: "Api Abadi Kawah",
        description: "Kumpulkan 3 Orb Elemen Api dari Salamander Overlord di Kawah Naga Mengamuk.",
        levelRequirement: 26,
        objectives: [{
            type: "collect", // Objektifnya mungkin harus kill monster spesifik untuk drop item kunci
            target: "orb-elemen-api", // Ini item kunci, jadi cara dapatnya mungkin dari kill
            count: 3,
            location: "dg010"
        }], // Asumsi Salamander Overlord drop orb ini
        rewards: {
            gold: 3000,
            xp: 3600,
            items: {
                'diamond': 1
            }
        },
        isRepeatable: true
    },
    "q023": {
        id: "q023",
        name: "Ritual Pengikat Jiwa",
        description: "Kumpulkan 10 Mystic Essence dari roh-roh di Nekropolis Para Raja.",
        levelRequirement: 28,
        objectives: [{
            type: "collect",
            target: "mystic-essence",
            count: 10,
            location: "dg012"
        }],
        rewards: {
            gold: 3200,
            xp: 3900,
            items: {
                'batu-obsidian': 3
            }
        },
        isRepeatable: true
    },
    "q024": {
        id: "q024",
        name: "Penguasa Nekropolis",
        description: "Kalahkan Royal Mummy yang bersemayam di Nekropolis Para Raja.",
        levelRequirement: 29,
        objectives: [{
            type: "kill",
            target: "Royal Mummy",
            count: 1,
            location: "dg012"
        }],
        rewards: {
            gold: 4000,
            xp: 4800,
            items: {
                'phoenix-down': 2,
                'ancient-scroll': 1
            }
        },
        isRepeatable: false
    },
    "q025": {
        id: "q025",
        name: "Bisa Sang Kaisar Gurun",
        description: "Kumpulkan 5 Racun Kalajengking dari pasukan Kalajengking Kaisar di Gurun Kalajengking Kaisar.",
        levelRequirement: 30,
        objectives: [{
            type: "collect",
            target: "racun-kalajengking",
            count: 5,
            location: "dg013"
        }],
        rewards: {
            gold: 2800,
            xp: 3400,
            items: {
                'panacea': 3,
                'sapphire': 1
            }
        },
        isRepeatable: true
    },
    "q026": {
        id: "q026",
        name: "Duel di Padang Pasir",
        description: "Kalahkan Desert Djinn yang kuat di Gurun Kalajengking Kaisar.",
        levelRequirement: 31,
        objectives: [{
            type: "kill",
            target: "Desert Djinn",
            count: 1,
            location: "dg013"
        }],
        rewards: {
            gold: 3500,
            xp: 4200,
            items: {
                'potion-of-strength': 3
            }
        },
        isRepeatable: false
    },
    "q027": {
        id: "q027",
        name: "Permata Berdarah Istana",
        description: "Temukan Ruby terkutuk di Istana Hantu Berdarah.",
        levelRequirement: 32,
        objectives: [{
            type: "collect",
            target: "ruby", //Ruby biasa, asumsikan ada cerita dibaliknya
            count: 2,
            location: "dg014"
        }],
        rewards: {
            gold: 4200,
            xp: 5000,
            items: {
                'demon-horn': 2
            }
        },
        isRepeatable: true
    },
    "q028": {
        id: "q028",
        name: "Penebusan Arwah Bangsawan",
        description: "Kalahkan Vampire Lordling di Istana Hantu Berdarah.",
        levelRequirement: 33,
        objectives: [{
            type: "kill",
            target: "Vampire Lordling",
            count: 1,
            location: "dg014"
        }],
        rewards: {
            gold: 5000,
            xp: 6000,
            items: {
                'elixir': 3,
                'jimat-keberuntungan': 1
            }
        },
        isRepeatable: false
    },
    "q029": {
        id: "q029",
        name: "Kemarahan Laut Dalam",
        description: "Kalahkan 2 Kraken's Chosen Tentacle di Domain Kraken Abyss.",
        levelRequirement: 35,
        objectives: [{
            type: "kill",
            target: "Kraken's Chosen Tentacle",
            count: 2,
            location: "dg015"
        }],
        rewards: {
            gold: 4500,
            xp: 5500,
            items: {
                'orb-elemen-air': 2,
                'diamond': 1
            }
        },
        isRepeatable: true
    },
    "q030": {
        id: "q030",
        name: "Mutiara dari Abyss",
        description: "Kumpulkan 3 Sapphire dari makhluk laut dalam di Domain Kraken Abyss.",
        levelRequirement: 36,
        objectives: [{
            type: "collect",
            target: "sapphire",
            count: 3,
            location: "dg015"
        }],
        rewards: {
            gold: 4000,
            xp: 4800,
            items: {
                'mega-potion': 1
            }
        },
        isRepeatable: true
    },
    "q031": {
        id: "q031",
        name: "Penambangan Mithril Berbahaya",
        description: "Kumpulkan 5 Bijih Mithril dari Tambang Mithril Terkutuk.",
        levelRequirement: 38,
        objectives: [{
            type: "collect",
            target: "bijih-mithril",
            count: 5,
            location: "dg016"
        }],
        rewards: {
            gold: 4800,
            xp: 5800,
            items: {
                'emerald': 2
            }
        },
        isRepeatable: true
    },
    "q032": {
        id: "q032",
        name: "Kapten Penambang Mayat",
        description: "Kalahkan Undead Miner Captain di Tambang Mithril Terkutuk.",
        levelRequirement: 39,
        objectives: [{
            type: "kill",
            target: "Undead Miner Captain",
            count: 1,
            location: "dg016"
        }],
        rewards: {
            gold: 5500,
            xp: 6600,
            items: {
                'x-potion': 4
            }
        },
        isRepeatable: true
    },
    "q033": {
        id: "q033",
        name: "Ujian Kehormatan Centaur",
        description: "Kalahkan Centaur Champion di Padang Perburuan Centaur Suci.",
        levelRequirement: 40,
        objectives: [{
            type: "kill",
            target: "Centaur Champion",
            count: 1,
            location: "dg017"
        }],
        rewards: {
            gold: 6000,
            xp: 7200,
            items: {
                'elven-composite-bow': 1,
                'enchanted-wood': 3
            }
        },
        isRepeatable: false
    },
    "q034": {
        id: "q034",
        name: "Berburu bersama Pegasus",
        description: "Kumpulkan 3 Bulu Pegasus dari Pegasus Colt di Padang Perburuan Centaur Suci (disimulasikan dengan bulu griffin).",
        levelRequirement: 41,
        objectives: [{
            type: "collect",
            target: "bulu-griffin",
            count: 3,
            location: "dg017"
        }],
        rewards: {
            gold: 5200,
            xp: 6200
        },
        isRepeatable: true
    },
    "q035": {
        id: "q035",
        name: "Menguak Rahasia Bintang Gila",
        description: "Kalahkan Mad Astrologer di Menara Kosmik Sang Ahli Nujum.",
        levelRequirement: 42,
        objectives: [{
            type: "kill",
            target: "Mad Astrologer",
            count: 1,
            location: "dg018"
        }],
        rewards: {
            gold: 6500,
            xp: 7800,
            items: {
                'archlich-staff': 1,
                'mystic-essence': 2
            }
        },
        isRepeatable: false
    },
    "q036": {
        id: "q036",
        name: "Fragmen Entitas Kosmik",
        description: "Kumpulkan 5 Mystic Essence dari makhluk di Menara Kosmik Sang Ahli Nujum.",
        levelRequirement: 43,
        objectives: [{
            type: "collect",
            target: "mystic-essence",
            count: 5,
            location: "dg018"
        }],
        rewards: {
            gold: 5800,
            xp: 6900,
            items: {
                'diamond': 2
            }
        },
        isRepeatable: true
    },
    "q037": {
        id: "q037",
        name: "Ekspedisi Kota Gelap Drow",
        description: "Temukan Gulungan Kuno di Kota Bawah Tanah Terlarang.",
        levelRequirement: 45,
        objectives: [{
            type: "collect",
            target: "ancient-scroll",
            count: 1,
            location: "dg019"
        }],
        rewards: {
            gold: 7000,
            xp: 8500,
            items: {
                'bijih-adamantite': 1
            }
        },
        isRepeatable: false
    },
    "q038": {
        id: "q038",
        name: "Penakluk Beholder Tyrant",
        description: "Kalahkan Beholder Tyrant yang menguasai Kota Bawah Tanah Terlarang.",
        levelRequirement: 46,
        objectives: [{
            type: "kill",
            target: "Beholder Tyrant",
            count: 1,
            location: "dg019"
        }],
        rewards: {
            gold: 8000,
            xp: 9500,
            items: {
                'phoenix-down': 3,
                'batu-obsidian': 5
            }
        },
        isRepeatable: false
    },
    "q039": {
        id: "q039",
        name: "Perang Melawan Gerbang Neraka",
        description: "Kalahkan Balor General yang menjaga Gerbang Neraka Terbuka.",
        levelRequirement: 50,
        rankRequirement: "S",
        objectives: [{
            type: "kill",
            target: "Balor General",
            count: 1,
            location: "dg020"
        }],
        rewards: {
            gold: 15000,
            xp: 20000,
            items: {
                'elixir': 5,
                'demon-horn': 3,
                'angel-feather': 1 // Hadiah kontras
            }
        },
        isRepeatable: false
    },
    "q040": {
        id: "q040",
        name: "Serangan ke Kastil Raja Iblis",
        description: "Masuki Kastil Raja Iblis Abyssal dan kalahkan THE DEMON KING. (HANYA PARTY)",
        levelRequirement: 70,
        rankRequirement: "SSS",
        isPartyOnlyQuest: true, // Flag untuk quest khusus party
        objectives: [{
            type: "kill", // Ini bisa disesuaikan, mungkin hanya mencapai?
            target: "THE DEMON KING",
            count: 1,
            location: "dg025" // Mengarah ke dungeon terakhir
        }],
        rewards: {
            gold: 200000, // Hadiah sangat besar
            xp: 300000,
            items: {
                'diamond': 10,
                'dragons-tear': 3,
                'angel-feather': 5,
                'orb-elemen-api': 3,
                'orb-elemen-air': 3,
                'orb-elemen-tanah': 3,
                'orb-elemen-angin': 3,
                'ancient-scroll': 2
            }
        },
        isRepeatable: false // Quest epik biasanya tidak repeatable
    }
};

const houses = {
    "house001": {
        id: "house001",
        name: "Gubuk Reyot",
        description: "Tempat berteduh sederhana, sedikit lebih baik dari tenda.",
        price: 500
    },
    "house002": {
        id: "house002",
        name: "Rumah Kayu Kecil",
        description: "Rumah kayu mungil di pinggir desa.",
        price: 2000
    },
    "house003": {
        id: "house003",
        name: "Pondok Hutan",
        description: "Pondok nyaman tersembunyi di dalam hutan.",
        price: 5000
    },
    "house004": {
        id: "house004",
        name: "Rumah Batu Bata",
        description: "Rumah kokoh terbuat dari batu bata di kota.",
        price: 10000
    },
    "house005": {
        id: "house005",
        name: "Toko Kosong",
        description: "Bangunan yang bisa dijadikan toko atau rumah.",
        price: 15000
    },
    "house006": {
        id: "house006",
        name: "Villa Tepi Pantai",
        description: "Rumah indah dengan pemandangan laut.",
        price: 25000
    },
    "house007": {
        id: "house007",
        name: "Menara Penyihir Mini",
        description: "Menara kecil untuk belajar sihir.",
        price: 35000
    },
    "house008": {
        id: "house008",
        name: "Rumah Pohon Elf",
        description: "Rumah unik di atas pohon besar.",
        price: 50000
    },
    "house009": {
        id: "house009",
        name: "Mansion Kota",
        description: "Rumah besar dan mewah di pusat kota.",
        price: 75000
    },
    "house010": {
        id: "house010",
        name: "Benteng Pribadi",
        description: "Benteng kecil dengan pertahanan.",
        price: 100000
    }
};

const jobs = {
    "job001": {
        id: "job001",
        name: "Penjaga Gerbang Desa",
        description: "Menjaga gerbang desa dari gangguan dan memastikan keamanan.",
        levelRequirement: 1,
        duration: 15000,
        rewards: {
            goldMin: 30,
            goldMax: 70,
            xpMin: 20,
            xpMax: 40
        },
        events: ["Mengusir gerombolan tikus.", "Membantu pedagang masuk desa.", "Berpatroli di sekitar gerbang."]
    },
    "job002": {
        id: "job002",
        name: "Pengumpul Kayu Bakar",
        description: "Mencari dan mengumpulkan kayu bakar di hutan untuk warga desa.",
        levelRequirement: 2,
        duration: 15000,
        rewards: {
            goldMin: 35,
            goldMax: 80,
            xpMin: 25,
            xpMax: 45,
            items: {
                'kayu-log': 2
            },
            itemChance: 0.6
        },
        events: ["Menemukan pohon tumbang yang bagus.", "Kapak sedikit tumpul.", "Beristirahat sambil menikmati hutan."]
    },
    "job003": {
        id: "job003",
        name: "Kurir Pesan Cepat",
        description: "Mengantarkan pesan penting antar pos jaga atau ke desa tetangga.",
        levelRequirement: 3,
        duration: 15000,
        rewards: {
            goldMin: 50,
            goldMax: 100,
            xpMin: 30,
            xpMax: 50
        },
        events: ["Mengambil jalan pintas.", "Hampir tersesat di persimpangan.", "Diberi minum oleh penerima pesan."]
    },
    "job004": {
        id: "job004",
        name: "Pembersih Kandang Ternak",
        description: "Membantu petani membersihkan kandang hewan ternak.",
        levelRequirement: 2,
        duration: 15000,
        rewards: {
            goldMin: 25,
            goldMax: 60,
            xpMin: 15,
            xpMax: 35
        },
        events: ["Hewan ternak terlihat senang.", "Menemukan telur ayam tambahan.", "Bau kandang sedikit menyengat."]
    },
    "job005": {
        id: "job005",
        name: "Penambang Kerikil Sungai",
        description: "Mengumpulkan kerikil dan batu berguna dari dasar sungai.",
        levelRequirement: 4,
        duration: 15000,
        rewards: {
            goldMin: 40,
            goldMax: 90,
            xpMin: 28,
            xpMax: 48,
            items: {
                'batu-sihir-kecil': 1
            },
            itemChance: 0.3
        },
        events: ["Menemukan batu berkilau.", "Air sungai sedang jernih.", "Kaki tergelincir sedikit."]
    },
    "job006": {
        id: "job006",
        name: "Pembuat Perangkap Sederhana",
        description: "Membuat perangkap kecil untuk menangkap hewan buruan kecil.",
        levelRequirement: 5,
        duration: 15000,
        rewards: {
            goldMin: 60,
            goldMax: 120,
            xpMin: 35,
            xpMax: 60
        },
        events: ["Perangkap berhasil menangkap kelinci.", "Belajar teknik membuat simpul baru.", "Menguji coba perangkap."]
    },
    "job007": {
        id: "job007",
        name: "Pemetik Buah Hutan",
        description: "Memetik buah-buahan liar yang aman dikonsumsi di hutan.",
        levelRequirement: 3,
        duration: 15000,
        rewards: {
            goldMin: 30,
            goldMax: 75,
            xpMin: 22,
            xpMax: 42,
            items: {
                'apel': 3
            },
            itemChance: 0.7
        },
        events: ["Menemukan pohon apel liar.", "Digigit semut merah.", "Berbagi buah dengan tupai."]
    },
    "job008": {
        id: "job008",
        name: "Asisten Penjaga Toko",
        description: "Membantu pemilik toko menata barang dan melayani pembeli.",
        levelRequirement: 4,
        duration: 15000,
        rewards: {
            goldMin: 45,
            goldMax: 95,
            xpMin: 30,
            xpMax: 50
        },
        events: ["Belajar cara tawar-menawar.", "Membersihkan debu di rak barang.", "Mendapat tip dari pelanggan."]
    },
    "job009": {
        id: "job009",
        name: "Penggosok Zirah Ksatria",
        description: "Membersihkan dan menggosok zirah para ksatria di barak.",
        levelRequirement: 6,
        duration: 15000,
        rewards: {
            goldMin: 70,
            goldMax: 130,
            xpMin: 40,
            xpMax: 65
        },
        events: ["Zirah terlihat mengkilap kembali.", "Mendengar cerita perang dari ksatria.", "Menemukan koin perak terselip."]
    },
    "job010": {
        id: "job010",
        name: "Juru Masak Kedai Sederhana",
        description: "Membantu memasak hidangan sederhana di kedai lokal.",
        levelRequirement: 5,
        duration: 15000,
        rewards: {
            goldMin: 55,
            goldMax: 110,
            xpMin: 33,
            xpMax: 55,
            items: {
                'roti-tawar': 1
            },
            itemChance: 0.4
        },
        events: ["Pelanggan memuji masakan.", "Belajar resep baru dari kepala koki.", "Sedikit gosong, tapi masih enak."]
    },
    "job011": {
        id: "job011",
        name: "Pengantar Air Bersih",
        description: "Mengambil dan mengantarkan air bersih dari sumber mata air ke rumah warga.",
        levelRequirement: 1,
        duration: 15000,
        rewards: {
            goldMin: 20,
            goldMax: 50,
            xpMin: 15,
            xpMax: 30
        },
        events: ["Warga berterima kasih.", "Menemukan jalan pintas ke sumber air.", "Embernya hampir tumpah."]
    },
    "job012": {
        id: "job012",
        name: "Penjaga Api Unggun Malam",
        description: "Memastikan api unggun di perkemahan atau pos jaga tetap menyala semalaman.",
        levelRequirement: 3,
        duration: 15000,
        rewards: {
            goldMin: 30,
            goldMax: 65,
            xpMin: 20,
            xpMax: 38
        },
        events: ["Mendengar suara hewan malam.", "Menambah kayu bakar agar api tetap besar.", "Hampir tertidur di pos jaga."]
    },
    "job013": {
        id: "job013",
        name: "Penyortir Surat di Kantor Pos",
        description: "Membantu menyortir surat dan paket di kantor pos desa.",
        levelRequirement: 4,
        duration: 15000,
        rewards: {
            goldMin: 40,
            goldMax: 85,
            xpMin: 25,
            xpMax: 45
        },
        events: ["Menemukan surat untuk teman.", "Belajar membaca stempel pos dari berbagai daerah.", "Kertasnya banyak sekali!"]
    },
    "job014": {
        id: "job014",
        name: "Perawat Tanaman di Kuil",
        description: "Merawat tanaman dan bunga suci di taman kuil.",
        levelRequirement: 5,
        duration: 15000,
        rewards: {
            goldMin: 50,
            goldMax: 100,
            xpMin: 30,
            xpMax: 52,
            items: {
                'bunga-malam': 1
            },
            itemChance: 0.2
        },
        events: ["Bunga-bunga mekar dengan indah.", "Mendapat pencerahan spiritual sejenak.", "Disengat lebah penjaga bunga."]
    },
    "job015": {
        id: "job015",
        name: "Pengukir Jimat Kayu",
        description: "Mengukir jimat keberuntungan sederhana dari kayu.",
        levelRequirement: 7,
        duration: 15000,
        rewards: {
            goldMin: 80,
            goldMax: 150,
            xpMin: 45,
            xpMax: 70
        },
        events: ["Hasil ukiran terlihat bagus.", "Menemukan pola ukiran baru.", "Jarinya sedikit tergores pisau ukir."]
    },
    "job0016": {
        id: "job0016",
        name: "Penyembuh hati",
        description: "Menjaga hati seseorang cewe dari gangguan cowo lain dan memastikan sembuh dari trauma.",
        levelRequirement: 1,
        duration: 15000,
        rewards: {
            goldMin: 9999,
            goldMax: 99999,
            xpMin: 999,
            xpMax: 9999
        },
        events: ["Mengusir gerombolan buaya.", "Membantu menyelesaikan trauma masalalu.", "jadi badut dia."]
    }
};


module.exports = {
    roles,
    items,
    dungeons,
    quests,
    houses,
    jobs
};